﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C__Q_04
{
    internal class SeparateClass
    {
        private void SayHello()
        {
            {
                Console.WriteLine("Hello world !");

            }
        }
    }
}
