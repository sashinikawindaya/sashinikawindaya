﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C__Lab_Q__1._1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Convertvalues converter = new Convertvalues();
            Converter.kilometerTometer();
        }
    }
}
