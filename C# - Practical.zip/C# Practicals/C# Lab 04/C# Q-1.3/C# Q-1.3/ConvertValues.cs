﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace C__Q_1._3
{
    internal class ConvertValues
    {
        public double KilometerTOMeter (double kilometer)
        {
            double meter = kilometer * 1000;
            return meter;
        }
    }
}
