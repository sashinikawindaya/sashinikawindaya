﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C__Q1._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Convertvalues converter = new Convertvalues();
            converter.KilometerToMeter();

            Console.ReadLine();
        }
    }
}
